import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SomethingH extends PApplet {




MainGame MG = new MainGame(640);
VapourLevel VL = new VapourLevel();
SoundFile music;

boolean MGOn = true;

public void setup()
{
  
  surface.setResizable(false);
  MG.setup();
  VL.setup();
  music = new SoundFile(this, dataPath("SH8.mp3"));
  music.loop(1,0.5f);
}


public void draw()
{
  if (MGOn)
  {
    MG.draw();
  } else
  {
    VL.draw();
  }
}

public void mousePressed()
{
  if(MGOn)
  {
   MG.mouseClick(mouseButton,this); //Need to pass refrence to this to chage MGOn
  }
}

public void keyPressed() {
  if (MGOn)
  {
    MG.setMove(key, true);
  } else
  {
    VL.setMove(key, true);
  }
}

public void keyReleased() {
  if (MGOn)
  {
    MG.setMove(key, false);
  } else
  {
    VL.setMove(key, false);
  }
}


class MainGame
{
  int RoadWidth = 100;
  //TODO Possibly store images in array
  PImage car;
  PImage WD;
  PImage SPD;
  PImage rock;
  PImage Cover;
  PImage LightG;
  PImage LightR;
  PImage WP;
  PFont SegF;
  PVector pos = new PVector(0, 0);
  float Speed = 10;
  float amt = 0;
  ArrayList<PVector> Rocks = new ArrayList<PVector>();
  ArrayList<PVector> RoadLines = new ArrayList<PVector>();
  ArrayList<PVector> WarpPlasma = new ArrayList<PVector>();
  int yOff = -20;
  int Width = 500;
  int Height = 500;
  int LinesCount;
  int LightCount = 0;
  int MaxPlasmas = 50;
  float SpeedCount = 0;
  float SpeedInc = 0.1f;
  int CurLight = 0;
  boolean[] Keys = new boolean[4];
  boolean[] Lights = new boolean[9];
  String WarpMessage = "";

  MainGame(int Width)
  {
    this.Width = Width;
    this.Height = Width;
  }


  public void setup()
  {
    pos = new PVector(Width/2, Height/2);
    //Load assets, should probs put this in initiliser 
    car = loadImage("CarWIP.png");
    WD = loadImage("WDTemp.png");
    rock = loadImage("Rock.png");
    SPD = loadImage("SPDTemp.png");
    Cover = loadImage("InterfaceCover.png");
    SegF = createFont("SEGF.ttf", 40);
    LightG = loadImage("SPDLiG.png");
    LightR = loadImage("SPDLiR.png");
    WP = loadImage("WarpPlasma.png");
    for (int y = 0; y < height; y+=90)
    {
      RoadLines.add(new PVector(Width/2, y));
    }
  }


  public void draw()
  {
    background(250, 180, 50);
    fill(0);
    rect((Width/2) - (RoadWidth/2), 0, RoadWidth, Height);//draw road
    DrawInterfaces((int)lerp(50, 88, amt), Lights, LightCount, MaxPlasmas, SpeedCount, WarpMessage);//draw UI stuff

    // Move,Draw and Delete rocks
    for (int i = Rocks.size()-1; i >=0; i--)
    {
      if (Rocks.get(i).y > Width)
      {
        Rocks.remove(i);
      } else
      {
        fill(150, 130, 25);
        PVector r = Rocks.get(i);
        image(rock, r.x, r.y, 20, 20);
        r.y += Speed;
        Rocks.set(i, r);
      }
    }
    //Move,Draw and Delete road lines
    for (int i = RoadLines.size()-1; i >=0; i--)
    {
      PVector n = RoadLines.get(i);
      if (n.y > height + 30)
      {
        RoadLines.remove(i);
      } else
      {
        stroke(255);
        line(n.x, n.y, n.x, n.y+30);
        n.y += Speed;
      }
    }
    //Move,Draw and Delete Warp Plasmas
    for (int i = WarpPlasma.size()-1; i >=0; i--)
    {
      PVector r = WarpPlasma.get(i);
      if (r.y > Width)
      {
        WarpPlasma.remove(i);
      } else if (Intersects((int)r.x-WP.width/2 + 3 , (int)r.y-WP.width/2 + 3, 20-6, 20-6, (int)pos.x - car.width/2, (int)(pos.y - yOff - car.height*1.5f), 26, 45))
      {
        WarpPlasma.remove(i);
        IncLights();
      } else
      {
        rectMode(CORNER);
        imageMode(CENTER);
        //fill(255, 0, 255);
        //rect((int)r.x-WP.width/2 + 3 , (int)r.y-WP.width/2 + 3, 20-6, 20-6);
        image(WP, r.x, r.y, 20, 20);
        r.y += Speed;
        WarpPlasma.set(i, r);
        rectMode(CORNER);
      }
    }



    //Keep track of when to add new lines where rate of line adding is proportional to speed
    LinesCount += 1;
    if (LinesCount >= 25 - Speed)
    {
      RoadLines.add(new PVector(Width/2, 0));
      LinesCount = 0;
    }
    //add new rocks
    if (random(100) > 90+ 10 -Speed)
    {
      int x = (int)random(Width-20);
      if (x+20 > (Width/2) - (RoadWidth/2) && x-20 < (Width/2) + (RoadWidth/2))
      {
      } else
      {
        Rocks.add(new PVector(x, 0));
      }
    }
    if (random(100) > 97 + 0.9f*(10 -Speed))
    {
      int rl = (int)random(100);
      if (rl >= 50)
      {
        WarpPlasma.add(new PVector((Width/2) - (RoadWidth/4), 0));
      } else
      {
        WarpPlasma.add(new PVector((Width/2) + (RoadWidth/4), 0));
      }
    }


    pushMatrix();
    //rectMode(CORNER);
    //rect((int)pos.x - car.width/2, pos.y - yOff - car.height*1.5, 26, 45); //Used for showing bounding box
    imageMode(CENTER);
    translate(pos.x, pos.y - yOff - car.height, 1);//translate to car pos

    //Check Keys array
    if (Keys[0])// key a
    {
      pos.x -= (int)lerp(3, 6, amt);
      if(pos.x <= car.width)
      {
       pos.x = car.width; 
      }
      else
      {
      rotate(-HALF_PI/4);
      }
    }
    if (Keys[1])// key d
    {
      pos.x += (int)lerp(3, 6, amt);
      if(pos.x >= Width-car.width)
      {
       pos.x = Width-car.width; 
      }
      else
      {
      rotate(HALF_PI/4);
      }
    }
    if (Keys[2])// key w
    {
      amt += amt+0.1f <= 1 ? 0.1f:0;
      if (amt+0.1f > 1.0f) amt = 1;
      Speed = lerp(10, 20, amt);
      yOff = (int)lerp(0, height/4, amt);
    } else
    {
      amt -= amt-0.02f >= 0 ? 0.02f:0;
      if (amt < 0.0f) amt = 0;
      Speed = lerp(10, 20, amt);
      yOff = (int)lerp(0, height/4, amt);
    }
    if (Keys[3])// key s
    {
      amt -= amt-0.1f >= 0 ? 0.1f:0;
      if (amt < 0.0f) amt = 0;
      Speed = lerp(10, 20, amt);
      yOff = (int)lerp(0, height/4, amt);
    }


    image(car, 0, 0);
    
    popMatrix();
    

    if (LightCount >= MaxPlasmas)
    {
      if ((int)lerp(50, 88, amt) == 88)
      {
        if (SpeedCount < 100)
        {
          WarpMessage = "Keep At 88";
          if (SpeedCount + SpeedInc > 100)
          {
            SpeedCount = 100;
          } else
          {
            SpeedCount += SpeedInc;
          }
        } else
        {
          WarpMessage = "WARP";
        }
      } else
      {
        if (SpeedCount >= 0)
        {
          WarpMessage = "Speed Up";
          if (SpeedCount - SpeedInc < 0)
          {
            SpeedCount = 0;
          } else
          {
            SpeedCount -= SpeedInc;
          }
        }
      }
    } else
    {
      WarpMessage = "Need More Plasma";
    }
  }

  public void mouseClick(int Button, SomethingH Parent)
  {
    println("clicked");
    if (Button == LEFT)
    {
      if (Intersects(mouseX, mouseY, 1, 1, Width + 16, height-WD.height + 87, 170, 100))
      {
        //warp drive clicked
        println("Warp Drive Clicked");
        if (LightCount >= MaxPlasmas)
        {
          Parent.MGOn = false;
        }
      }
    }
  }

  public boolean Intersects(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2)
  {

    if (x1 > x2 && x1 < x2 + w2 || x1+w1 > x2 && x1+w1 < x2+w2)
    {
      if (y1 > y2 && y1 < y2+h2 || y1+h1 > y2 && y1+h1 < y2+h2)
      {
        return true;
      }
    }
    return false;
  }

  public void IncLights()
  {
    LightCount += 1;
    String b = binary(LightCount, 9);
    for (int i = 0; i < b.length(); i++)
    {
      if (b.charAt(i) == '1')
      {
        Lights[i] = true;
      } else
      {
        Lights[i] = false;
      }
    }
  }



  public boolean setMove(int k, boolean b) {
    switch (k) {
    case 'w':
      return Keys[2] = b;

    case 's':
      return Keys[3] = b;

    case 'a':
      return Keys[0] = b;

    case 'd':
      return Keys[1] = b;

    default:
      return b;
    }
  }

  public void DrawInterfaces(int Speed, boolean[] SPDLights, int PlasmaCount, int MaxPlasma, float SpeedCount, String WarpMessage)
  {
    rect(Width, 0, width-Width, height);
    image(WD, width - WD.height/2, height-WD.height/2);
    image(SPD, width - SPD.height/2, SPD.height/2);
    image(Cover, width - WD.height/2, height-WD.height/2);
    image(Cover, width - SPD.height/2, SPD.height/2);
    fill(255, 0, 0);
    textFont(SegF);
    text(Speed + "mph", Width + 20, 53);
    fill(0, 255, 0);
    textSize(9);
    text("Plasma Count: " + PlasmaCount, Width + 22, 106);
    text("Plasma Needed: " + MaxPlasma, Width + 22, 131);

    if (WarpMessage != "WARP")
    {
      textSize(25);
      int LineSpace = 0;
      String[] MsgSplit = WarpMessage.split(" ");
      for (String s : MsgSplit)
      {
        text(s, Width+20, height-85+LineSpace);
        LineSpace += 30;
      }
    } else
    {
      if (Intersects(mouseX, mouseY, 1, 1, Width + 16, height-WD.height + 87, 170, 100))
      {
        fill(255,0,0);
      }
      else
      {
       fill(0,255,0); 
      }
      textSize(40);
      text(WarpMessage,Width+37,height-45);
    }


    for (int i = 0; i < 9; i++)
    {
      if (SpeedCount < (100/9)*i)
      {
        image(LightR, Width + 22  + (i*20), height-130);
      } else
      {
        image(LightG, Width + 22 + (i*20), height-130);
      }
      if (SPDLights[i] == true || PlasmaCount >= MaxPlasma)
      {
        image(LightG, Width + 20  + (i*20), 80);
      } else
      {
        image(LightR, Width + 20 + (i*20), 80);
      }
    }
  }
}
class VapourLevel
{
  int cols, rows;
  int scl = 20;
  int w = 2000;
  int h = 1600;
  boolean[] Keys = new boolean[4];
  float flying = 0;

  float[][] terrain;

  PImage CarBack;
  PImage BG;

  PVector CarSize = new PVector(80, 48);
  PVector CarPos = new PVector(0,0);

  public void setup() {
    cols = w / scl;
    rows = h/ scl;
    terrain = new float[cols][rows];
    CarBack = loadImage(dataPath("CarBackRet.png"));
    //BG = loadImage(dataPath("VLBack.png"));
    ChangeCarSize(15);
  }


  public void draw() {
    background(0);
    
    //generate perlin noise stuff
    flying -= 0.1f;//inc perlin counter
    float yoff = flying;
    for (int y = 0; y < rows; y++) {
      float xoff = 0;
      for (int x = 0; x < cols; x++) {

        terrain[x][y] = noise(xoff, yoff);

        xoff += 0.2f;
      }
      yoff += 0.2f;
    }



    
    noFill();


    //render perlin feild
    pushMatrix();
    translate(width/2, height/2+50);
    rotateX(PI/2);
    translate(-w/2, -h/2);
    fill(100);
    //rect((cols*20)/2 - 45, 0, 90, rows * 20);
    noFill();
    for (int y = 0; y < rows-1; y++) {

      beginShape(TRIANGLE_STRIP);
      for (int x = 0; x < cols; x++) {
        stroke(ColourConv(terrain[x][y], 1)-50, 0, ColourConv(terrain[x][y], 1));
        if (x >= (cols/2) + 4 || x <= (cols/2) - 4)
        {

          vertex(x*scl, y*scl, lerp(-100, 100, terrain[x][y]));
          vertex(x*scl, (y+1)*scl, lerp(-100, 100, terrain[x][y]));
          //rect(x*scl, y*scl, scl, scl);
        } else
        {
          //noStroke();
          vertex(x*scl, y*scl, 0);
          vertex(x*scl, (y+1)*scl, 0);
        }
      }
      endShape();
    }
    popMatrix();
    //draw car
    pushMatrix();
    translate(width/2, height/2 + CarSize.y,85);
    DrawImage3D(CarBack, (int)CarPos.x, (int)CarPos.y, 300, (int)CarSize.x, (int)CarSize.y);
    popMatrix();
    
    
    if (Keys[0])// key a
    {
      CarPos.x -= CarPos.x > -15 ? 3:0;
    }
    if (Keys[1])// key d
    {
      CarPos.x += CarPos.x < 15 ? 3:0;
    }
    
  }


  public void ChangeCarSize(float w)
  {
    //Original size 226 by 136 = 113 : 68 
    //h = (w*68)/113
    CarSize.y = (w*68)/113;
    CarSize.x = w;
  }
  public boolean setMove(int k, boolean b) {
    switch (k) {
    case 'w':
      return Keys[2] = b;

    case 's':
      return Keys[3] = b;

    case 'a':
      return Keys[0] = b;

    case 'd':
      return Keys[1] = b;

    default:
      return b;
    }
  }
}



public int ColourConv(float i, int max)
{
  //println(i/max);
  return (int)lerp(0, 255, (float)i/(float)max);
}

public void DrawImage3D(PImage img, int x, int y, int z, int w, int h)
{
  //need to draw as shape to set z pos
  int xC = x - w/2;//x Centered
  noStroke();
  beginShape();
  texture(img);
  vertex(xC, y, z, 0, 0);
  vertex(xC + w, y, z, img.width, 0);
  vertex(xC+w, y+h, z, img.width, img.height);
  vertex(xC, y+h, z, 0, img.height);
  endShape();
}
  public void settings() {  size(840, 600, P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SomethingH" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
