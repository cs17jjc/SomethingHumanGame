import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SomethingH extends PApplet {




MainGame MG = new MainGame();
VapourLevel VL = new VapourLevel();
SoundFile music;

boolean MGOn = true;

public void setup()
{
  
  MG.setup();
  VL.setup();
  music = new SoundFile(this,dataPath("SH8.mp3"));
  music.play(1,0.3f);
}


public void draw()
{
  if(MGOn)
  {
  MG.draw();
  }
  else
  {
  VL.draw();
  }
}

public void mousePressed()
{
 MGOn = !MGOn; 
}

public void keyPressed() {
  if(MGOn)
  {
  MG.setMove(key, true);
  }
}

public void keyReleased() {
  if(MGOn)
  {
  MG.setMove(key, false);
  }
}


class MainGame
{
  int RoadWidth = 100;
  PImage car;
  PImage WD;
  PImage SPD;
  PImage rock;
  PImage Cover;
  PImage LightG;
  PImage LightR;
  PImage WP;
  PFont SegF;
  PVector pos = new PVector(0, 0);
  float Speed = 10;
  float amt = 0;
  ArrayList<PVector> Rocks = new ArrayList<PVector>();
  ArrayList<PVector> RoadLines = new ArrayList<PVector>();
  ArrayList<PVector> WarpPlasma = new ArrayList<PVector>();
  int yOff = -20;
  int Width = 500;
  int Height = 500;
  int LinesCount;
  int LightCount = 0;
  int CurLight = 0;
  boolean[] Keys = new boolean[4];
  boolean[] Lights = new boolean[9];


  public void setup()
  {
    pos = new PVector(Width/2, Height/3);
    car = loadImage("CarWIP.png");
    WD = loadImage("WDTemp.png");
    rock = loadImage("Rock.png");
    SPD = loadImage("SPDTemp.png");
    Cover = loadImage("InterfaceCover.png");
    SegF = createFont("SEGF.ttf", 40);
    LightG = loadImage("SPDLiG.png");
    LightR = loadImage("SPDLiR.png");
    WP = loadImage("WarpPlasma.png");
    for (int y = 0; y < height; y+=90)
    {
      RoadLines.add(new PVector(Width/2, y));
    }
  }


  public void draw()
  {
    background(250, 180, 50);
    fill(0);
    rect((Width/2) - (RoadWidth/2), 0, RoadWidth, Height);
    DrawInterfaces((int)lerp(50, 93, amt), Lights);

    // Move,Draw and Delete rocks
    for (int i = Rocks.size()-1; i >=0; i--)
    {
      if (Rocks.get(i).y > Width)
      {
        Rocks.remove(i);
      } else
      {
        fill(150, 130, 25);
        PVector r = Rocks.get(i);
        image(rock, r.x, r.y, 20, 20);
        r.y += Speed;
        Rocks.set(i, r);
      }
    }
    //Move,Draw and Delete road lines
    for (int i = RoadLines.size()-1; i >=0; i--)
    {
      PVector n = RoadLines.get(i);
      if (n.y > height + 30)
      {
        RoadLines.remove(i);
      } else
      {
        stroke(255);
        line(n.x, n.y, n.x, n.y+30);
        n.y += Speed;
      }
    }
    //Move,Draw and Delete Warp Plasmas
    for (int i = WarpPlasma.size()-1; i >=0; i--)
    {
      PVector r = WarpPlasma.get(i);
      if (r.y > Width)
      {
        WarpPlasma.remove(i);
      } else if (Intersects((int)r.x, (int)r.y, 20, 20, (int)pos.x, (int)(pos.y - yOff), 26, 45))
      {
        WarpPlasma.remove(i);
        IncLights();
      } else
      {
        rectMode(CENTER);
        fill(255, 0, 255);
        image(WP, r.x, r.y, 20, 20);
        r.y += Speed;
        WarpPlasma.set(i, r);
        rectMode(CORNER);
      }
    }



    //Keep track of when to add new lines where rate of line adding is proportional to speed
    LinesCount += 1;
    if (LinesCount >= 25 - Speed)
    {
      RoadLines.add(new PVector(Width/2, 0));
      LinesCount = 0;
    }
    //add new rocks
    if (random(100) > 90+ 10 -Speed)
    {
      int x = (int)random(Width-20);
      if (x+20 > (Width/2) - (RoadWidth/2) && x-20 < (Width/2) + (RoadWidth/2))
      {
      } else
      {
        Rocks.add(new PVector(x, 0));
      }
    }
    if (random(100) > 97 + 0.9f*(10 -Speed))
    {
      int rl = (int)random(100);
      if (rl >= 50)
      {
        WarpPlasma.add(new PVector((Width/2) - (RoadWidth/4), 0));
      } else
      {
        WarpPlasma.add(new PVector((Width/2) + (RoadWidth/4), 0));
      }
    }



    imageMode(CENTER);
    translate(pos.x, pos.y - yOff,1);

    //Check Keys array
    if (Keys[0])// key a
    {
      pos.x -= (int)lerp(3, 6, amt);
      rotate(-HALF_PI/4);
    }
    if (Keys[1])// key d
    {
      pos.x += (int)lerp(3, 6, amt);
      rotate(HALF_PI/4);
    }
    if (Keys[2])// key w
    {
      amt += amt+0.1f <= 1 ? 0.1f:0;
      Speed = lerp(10, 20, amt);
      yOff = (int)lerp(-70, 30, amt);
    } else
    {
      amt -= amt-0.02f >= 0 ? 0.02f:0;
      Speed = lerp(10, 20, amt);
      yOff = (int)lerp(-70, 30, amt);
    }
    if (Keys[3])// key s
    {
      amt -= amt-0.1f >= 0 ? 0.1f:0;
      Speed = lerp(10, 20, amt);
      yOff = (int)lerp(-70, 30, amt);
    }


    image(car, 0, 0);
  }

  public boolean Intersects(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2)
  {
    if (x1 > x2 && x1 < x2 + w2)
    {
      if (y1 > y2 && y1 < y2 + h2)
      {
        //x1y1 is in x2y2
        return true;
      }
    }
    if (x1 + w1 > x2 && x2 + w2 > x1)
    {
      if (y1 + h1 > y2 && y2 + h2 > y1)
      {
        //Intersection
        return true;
      }
    }
    return false;
  }

  public void IncLights()
  {
    LightCount += 1;
    String b = binary(LightCount, 9);
    for (int i = 0; i < b.length(); i++)
    {
      if (b.charAt(i) == '1')
      {
        Lights[i] = true;
      } else
      {
        Lights[i] = false;
      }
    }
  }



  public boolean setMove(int k, boolean b) {
    switch (k) {
    case 'w':
      return Keys[2] = b;

    case 's':
      return Keys[3] = b;

    case 'a':
      return Keys[0] = b;

    case 'd':
      return Keys[1] = b;

    default:
      return b;
    }
  }

  public void DrawInterfaces(int Speed, boolean[] SPDLights)
  {
    rect(Width, 0, width-Width, height);
    image(WD, width - WD.height/2, height-WD.height/2);
    image(SPD, width - SPD.height/2, SPD.height/2);
    image(Cover, width - WD.height/2, height-WD.height/2);
    image(Cover, width - SPD.height/2, SPD.height/2);
    fill(255, 0, 0);
    textFont(SegF);
    text(Speed + "mph", Width + 20, 53);
    for (int i = 0; i < 9; i++)
    {
      if (SPDLights[i] == true)
      {
        image(LightG, Width + 20  + (i*20), 80);
      } else
      {
        image(LightR, Width + 20 + (i*20), 80);
      }
    }
  }
}
class VapourLevel
{
  int cols, rows;
  int scl = 20;
  int w = 2000;
  int h = 1600;

  float flying = 0;

  float[][] terrain;

  PImage CarBack;

  PVector CarSize = new PVector(80, 48);
  
  public void setup() {
    cols = w / scl;
    rows = h/ scl;
    terrain = new float[cols][rows];
    CarBack = loadImage(dataPath("CarBackRet.png"));
  }


  public void draw() {

    flying -= 0.1f;

    float yoff = flying;
    for (int y = 0; y < rows; y++) {
      float xoff = 0;
      for (int x = 0; x < cols; x++) {

        terrain[x][y] = noise(xoff, yoff);

        xoff += 0.2f;
      }
      yoff += 0.2f;
    }



    background(0);
    noFill();



    pushMatrix();
    translate(width/2, height/2+50);
    rotateX(PI/2);
    translate(-w/2, -h/2);
    fill(100);
    //rect((cols*20)/2 - 45, 0, 90, rows * 20);
    noFill();


    for (int y = 0; y < rows-1; y++) {

      beginShape(TRIANGLE_STRIP);
      for (int x = 0; x < cols; x++) {
        stroke(ColourConv(terrain[x][y], 1)-50, 0, ColourConv(terrain[x][y], 1));
        if (x >= (cols/2) + 4 || x <= (cols/2) - 4)
        {

          vertex(x*scl, y*scl, lerp(-100, 100, terrain[x][y]));
          vertex(x*scl, (y+1)*scl, lerp(-100, 100, terrain[x][y]));
          //rect(x*scl, y*scl, scl, scl);
        } else
        {
          //noStroke();
          vertex(x*scl, y*scl, 0);
          vertex(x*scl, (y+1)*scl, 0);
        }
      }
      endShape();
    }
    popMatrix();
    pushMatrix();
    translate(width/2, (height - CarBack.height*2) + CarSize.y/2);
    DrawImge3D(CarBack, 0, 0, 300, (int)CarSize.x, (int)CarSize.y);
    popMatrix();
  }


  public void ChangeCarSize(float w)
  {
    //Original size 226 by 136 = 113 : 68 
    //h = (w*68)/113
    CarSize.y = (w*68)/113;
    CarSize.x = w;
  }
}



public int ColourConv(float i, int max)
{
  //println(i/max);
  return (int)lerp(0, 255, (float)i/(float)max);
}

public void DrawImge3D(PImage img, int x, int y, int z, int w, int h)
{
  int xC = x - w/2;//x Centered
  noStroke();
  beginShape();
  texture(img);
  vertex(xC, y, z, 0, 0);
  vertex(xC + w, y, z, img.width, 0);
  vertex(xC+w, y+h, z, img.width, img.height);
  vertex(xC, y+h, z, 0, img.height);
  endShape();
}
  public void settings() {  size(700, 500,P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SomethingH" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
